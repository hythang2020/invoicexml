const express = require("express");

const router = express.Router();
const inputController = require('../controllers/input/input.controller');

//GET INPUT LIST//
router.get('/',inputController.index);
//END GET INPUT LIST //

//GET INPUT LIST//
router.get('/upload-hoadon',inputController.uploadxml);
//END GET INPUT LIST //


//POST INPUT LIST//
router.post('/upload-input',inputController.postuploadxml);
//END POST INPUT LIST //

//GET Edit PROMOTION LIST //

router.get('/viewspdf/:plhd/:pdf',inputController.pdf);
// router.get('/viewspdf/:id/:pdf',inputController.pdf);
//END GET Edit PROMOTION LIST //

//Router Info xml - Info By Id
router.get('/api/:id',inputController.apigethd);


module.exports = router;